@echo off
"%~dp0LazyStick-Huawei-Auth.exe" --local
